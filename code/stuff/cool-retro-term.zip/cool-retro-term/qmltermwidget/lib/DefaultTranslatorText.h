"keyboard \"Fallback Key Translator\"\n"
"key Tab : \"\\t\" \0"
